/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/25 16:08:17 by graja             #+#    #+#             */
/*   Updated: 2021/02/25 19:34:38 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_power(int nb, int power)
{
	int result;

	if (power < 0)
		return (0);
	if (power == 0)
		return (1);
	result = nb;
	if (power > 1)
		result = nb * ft_power(nb, power - 1);
	return (result);
}

int	ft_sqrt(int nb)
{
	int	i;

	if (nb == 0)
		return (0);
	i = 1;
	while (i <= nb)
	{
		if (ft_power(i, 2) == nb)
			return (i);
		i++;
	}
	return (0);
}
