/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/13 08:22:31 by graja             #+#    #+#             */
/*   Updated: 2021/02/14 14:29:19 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print_line(int y, int maxx, int maxy)
{
	char	show;
	int		i;

	i = 1;
	while (i <= maxx)
	{
		show = '*';
		if (((i == 1) && (y == 1)) ||
		((i == maxx) && (y == maxy) && (y > 1)))
		{
			show = '/';
		}
		if (((i == maxx) && (y == 1) && (maxx > 1)) ||
		((i == 1) && (y == maxy) && (maxy != 1)))
		{
			show = '\\';
		}
		if ((i > 1) && (i < maxx) && (y > 1) && (y < maxy))
		{
			show = ' ';
		}
		ft_putchar(show);
		i++;
	}
	ft_putchar('\n');
}

void	rush(int x, int y)
{
	int i;

	i = 1;
	while ((i <= y) && (x > 0) && (y > 0))
	{
		ft_print_line(i, x, y);
		i++;
	}
}
