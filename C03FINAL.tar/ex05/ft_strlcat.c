/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/22 13:23:35 by graja             #+#    #+#             */
/*   Updated: 2021/02/23 10:48:06 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlen(char *ptr)
{
	unsigned int	i;
	char			*bkp;

	bkp = ptr;
	i = 0;
	while (*bkp != '\0')
	{
		i++;
		bkp++;
	}
	return (i);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int nb)
{
	char			*tgt;
	char			*cpy;
	unsigned int	i;
	unsigned int	len;

	len = ft_strlen(dest);
	tgt = dest;
	cpy = src;
	i = len + 1;
	while (*tgt != '\0')
		tgt++;
	while ((i <= nb) && (*cpy != '\0'))
	{
		*tgt = *cpy;
		cpy++;
		tgt++;
		i++;
	}
	if ((nb - i) > 0)
		*tgt = '\0';
	return (ft_strlen(dest));
}
