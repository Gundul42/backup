/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/22 12:02:46 by graja             #+#    #+#             */
/*   Updated: 2021/02/23 09:21:05 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int				ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	if (n == 0)
		return (0);
	i = 0;
	while (s1[i] && s2[i] && (s1[i] == s2[i]) && (i < n - 1))
		i++;
	if (s1[i] < s2[i])
		return (-1);
	else if (s1[i] > s2[i])
		return (1);
	return (0);
}

unsigned int	ft_strlen(char *ptr)
{
	unsigned int	i;
	char			*bkp;

	bkp = ptr;
	i = 0;
	while (*bkp != '\0')
	{
		i++;
		bkp++;
	}
	return (i);
}

char			*ft_strstr(char *pool, char *fish)
{
	unsigned int	i;
	unsigned int	len;
	unsigned int	poollen;
	char			*bkp;
	char			*find;

	i = 1;
	len = ft_strlen(fish);
	poollen = ft_strlen(pool);
	bkp = pool;
	find = fish;
	if ((len > poollen) || (len == 0))
		return (0);
	while (i <= (poollen - len + 1))
	{
		if ((*bkp == *find) && (ft_strncmp(bkp, find, len) == 0))
			return (bkp);
		bkp++;
		i++;
	}
	return (0);
}
