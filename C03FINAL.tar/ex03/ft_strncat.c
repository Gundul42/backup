/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/22 09:03:48 by graja             #+#    #+#             */
/*   Updated: 2021/02/22 15:19:10 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlen(char *ptr)
{
	unsigned int	i;
	char			*bkp;

	bkp = ptr;
	i = 0;
	while (*bkp != '\0')
	{
		i++;
		bkp++;
	}
	return (i);
}

char			*ft_strncat(char *dest, char *src, unsigned int nb)
{
	char			*tgt;
	char			*cpy;
	unsigned int	i;
	unsigned int	len;

	len = ft_strlen(src);
	tgt = dest;
	cpy = src;
	i = 0;
	if (nb > len)
		nb = len;
	while (*tgt != '\0')
		tgt++;
	while (i < nb)
	{
		*tgt = *cpy;
		cpy++;
		tgt++;
		i++;
	}
	*tgt = '\0';
	return (dest);
}
