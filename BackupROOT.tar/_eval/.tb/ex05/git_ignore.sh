git status -s --ignored | grep '!!' | sed 's/!! //'
