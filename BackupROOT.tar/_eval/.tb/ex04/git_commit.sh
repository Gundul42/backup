git log --pretty=%H -n 5
