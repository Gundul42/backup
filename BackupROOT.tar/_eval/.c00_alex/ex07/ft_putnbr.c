/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aghia <aghia@student.42wolfsburg.de>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/12 09:17:14 by aghia             #+#    #+#             */
/*   Updated: 2021/02/15 12:11:10 by aghia            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int		ft_abs(int nb)
{
	if (nb < 0)
		nb = -nb;
	return (nb);
}

void	ft_write_number(int nbrev, int last_digit)
{
	char c;

	while (nbrev != 0)
	{
		c = '0' + nbrev % 10;
		write(1, &c, 1);
		nbrev = nbrev / 10;
	}
	c = '0' + last_digit;
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	int		nbrev;
	int		last_digit;

	if (nb == 0)
		write(1, "0", 1);
	else
	{
		nbrev = 0;
		last_digit = ft_abs((nb % 10));
		nb = nb / 10;
		if (nb < 0)
		{
			write(1, "-", 1);
			nb = ft_abs(nb);
		}
		while (nb != 0)
		{
			nbrev = nbrev * 10 + nb % 10;
			nb = nb / 10;
		}
		ft_write_number(nbrev, last_digit);
	}
}
