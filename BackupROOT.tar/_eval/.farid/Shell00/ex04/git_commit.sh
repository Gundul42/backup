#!/bin/bh
git log --format='%H' -n5
