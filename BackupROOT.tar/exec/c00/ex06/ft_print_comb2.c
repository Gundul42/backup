/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/11 18:27:46 by graja             #+#    #+#             */
/*   Updated: 2021/02/11 21:48:15 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_char(char c)
{
	write(1, &c, 1);
}

void	ft_print_num(int n)
{
	char	alpha;
	char	beta;
	int		tenth;

	if (n > 9)
	{
		tenth = n / 10;
		beta = 48 + tenth;
		ft_print_char(beta);
		n = n - tenth * 10;
	}
	else
	{
		ft_print_char('0');
	}
	alpha = 48 + n;
	ft_print_char(alpha);
}

void	ft_print_block(int a, int b)
{
	ft_print_num(a);
	ft_print_char(' ');
	ft_print_num(b);
	if (a + b < 197)
	{
		ft_print_char(',');
		ft_print_char(' ');
	}
}

void	ft_print_comb2(void)
{
	int	i;
	int	j;

	i = 0;
	while (i < 99)
	{
		j = i + 1;
		while (j < 100)
		{
			ft_print_block(i, j);
			j++;
		}
		i++;
	}
}
