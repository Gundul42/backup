/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/11 15:58:57 by graja             #+#    #+#             */
/*   Updated: 2021/02/11 17:48:54 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_char(char c)
{
	write(1, &c, 1);
}

void	ft_print_block(int i, int j, int k)
{
	char first;
	char second;
	char third;

	first = 48 + i;
	second = 48 + j;
	third = 48 + k;
	ft_print_char(first);
	ft_print_char(second);
	ft_print_char(third);
	if (i + j + k < 24)
	{
		ft_print_char(',');
		ft_print_char(' ');
	}
}

void	ft_print_comb(void)
{
	int	i;
	int	j;
	int	k;

	i = 0;
	while (i < 8)
	{
		j = i + 1;
		while (j < 10)
		{
			k = j + 1;
			while (k < 10)
			{
				ft_print_block(i, j, k);
				k++;
			}
			j++;
		}
		i++;
	}
}
