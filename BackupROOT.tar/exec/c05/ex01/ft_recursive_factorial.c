/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/25 13:25:20 by graja             #+#    #+#             */
/*   Updated: 2021/02/25 19:54:10 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nr)
{
	int result;

	if (nr < 0)
		return (0);
	if (nr == 0)
		return (1);
	result = nr;
	if (nr > 1)
	{
		result *= ft_recursive_factorial(nr - 1);
	}
	return (result);
}
