/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/25 13:25:20 by graja             #+#    #+#             */
/*   Updated: 2021/02/25 13:34:34 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nr)
{
	int i;
	int result;

	if (nr < 0)
		return (0);
	result = 1;
	i = 1;
	while (i < nr)
	{
		i++;
		result *= i;
	}
	return (result);
}
