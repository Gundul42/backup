/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr_non_printable.c                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/18 07:52:22 by graja             #+#    #+#             */
/*   Updated: 2021/02/20 13:22:43 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int		ft_char_is_printable(char c)
{
	if (((c > 31) && (c < 127)))
		return (1);
	else
		return (0);
}

void	ft_printhex(char c)
{
	int	i;
	int	help;

	i = 0;
	help = c / 16;
	while (i < 2)
	{
		if (help <= 9)
			ft_putchar(48 + help);
		else
			ft_putchar(87 + help);
		help = c % 16;
		i++;
	}
}

void	ft_putstr_non_printable(char *str)
{
	char	*bkp;

	bkp = str;
	while (*bkp != '\0')
	{
		if (ft_char_is_printable(*bkp) == 1)
			ft_putchar(*bkp);
		else
		{
			ft_putchar('\\');
			ft_printhex(*bkp);
		}
		bkp++;
	}
}
