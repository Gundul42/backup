/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/20 12:42:04 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int				ft_strlen(char *str)
{
	char			*backup;
	unsigned int	count;

	count = 0;
	backup = str;
	while (*backup != '\0')
	{
		backup++;
		count++;
	}
	return (count);
}

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size)
{
	char			*sbkp;
	char			*bkp;
	unsigned int	i;

	sbkp = src;
	bkp = dest;
	if (size == 0)
		return (0);
	i = 0;
	while ((*sbkp != '\0') && (i < (size - 1)))
	{
		*bkp = *sbkp;
		bkp++;
		sbkp++;
		i++;
	}
	*bkp = '\0';
	return (ft_strlen(src));
}
