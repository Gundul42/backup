/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_memory.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/18 10:32:02 by graja             #+#    #+#             */
/*   Updated: 2021/02/19 16:44:35 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_printhex(unsigned char c)
{
	int		i;
	int		help;
	char	pri;

	i = 0;
	help = c / 16;
	while (i < 2)
	{
		if (help <= 9)
		{
			pri = 48 + help;
			write(1, &pri, 1);
		}
		else
		{
			pri = 87 + help;
			write(1, &pri, 1);
		}
		help = c % 16;
		i++;
	}
}

void	ft_printadr(void *adr)
{
	char	*ptr;
	int		i;
	int		size;

	size = sizeof(adr);
	ptr = (char *)&adr;
	ptr += (size - 1);
	i = 0;
	while (i < size)
	{
		ft_printhex(*ptr);
		ptr--;
		i++;
	}
	write(1, ": ", 2);
}

void	ft_print_coloms(char *start, int n)
{
	int		i;
	int		j;
	char	*bkp;

	i = 0;
	j = 0;
	bkp = start;
	while (i < 16)
	{
		if (i < n)
			ft_printhex(*bkp);
		else
			write(1, " ", 1);
		if (j > 0)
		{
			write(1, " ", 1);
			j = -1;
		}
		j++;
		bkp++;
		i++;
	}
}

void	ft_print_readable(char *start, int n)
{
	int		i;
	char	*bkp;

	i = 0;
	bkp = start;
	while (i < n)
	{
		if ((*bkp > 31) && (*bkp < 127))
			write(1, bkp, 1);
		else
			write(1, ".", 1);
		bkp++;
		i++;
	}
	write(1, "\n", 1);
}

void	*ft_print_memory(void *addr, unsigned int size)
{
	char	*start;

	start = addr;
	while (size > 0)
	{
		if (size > 16)
		{
			ft_printadr(start);
			ft_print_coloms(start, 16);
			ft_print_readable(start, 16);
			size = size - 16;
			start += 16;
		}
		else
		{
			ft_printadr(start);
			ft_print_coloms(start, size);
			ft_print_readable(start, size);
			size = 0;
		}
	}
	return (addr);
}
