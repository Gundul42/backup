/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/19 17:02:26 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strlen(char *str)
{
	char	*backup;
	int		count;

	count = 0;
	backup = str;
	while (*backup != '\0')
	{
		backup++;
		count++;
	}
	return (count);
}

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	char			*backup;
	unsigned int	length;
	unsigned int	i;

	backup = dest;
	length = ft_strlen(src);
	i = 0;
	while (i < n)
	{
		if (i < length)
		{
			*dest = *src;
			dest++;
			src++;
		}
		else
		{
			*dest = '\0';
			dest++;
		}
		i++;
	}
	dest = backup;
	return (backup);
}
