/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/14 16:10:00 by graja             #+#    #+#             */
/*   Updated: 2021/02/16 08:40:32 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_swap(int *a, int *b)
{
	int	swapper;

	swapper = *a;
	*a = *b;
	*b = swapper;
}

void	ft_sort_int_tab(int *tab, int size)
{
	int	*backup;
	int	*swp1;
	int	*swp2;
	int	i;
	int	exit;

	exit = 1;
	while ((exit != 0) && (size > 1))
	{
		backup = tab;
		exit = 0;
		i = 0;
		while (i < size - 1)
		{
			swp1 = backup + i;
			swp2 = backup + i + 1;
			if (*swp1 > *swp2)
			{
				ft_swap(swp1, swp2);
				exit = 1;
			}
			i++;
		}
	}
}
