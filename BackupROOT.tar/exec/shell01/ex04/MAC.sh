#ifconfig | grep ether | tr " " "," | cut -d, -f10
ifconfig | grep ether | cut -c 15-31
