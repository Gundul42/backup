/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/23 13:14:14 by graja             #+#    #+#             */
/*   Updated: 2021/02/24 15:31:08 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_isnumber(char c)
{
	if ((c > 47) && (c < 58))
		return (1);
	else
		return (0);
}

int	ft_isspace(char c)
{
	if ((c == 32) || ((c > 8) && (c < 14)))
		return (1);
	else
		return (0);
}

int	ft_isplmin(char c)
{
	if (c == 45)
		return (-1);
	else if (c == 43)
		return (1);
	return (0);
}

int	ft_atoi(char *str)
{
	int	minus;
	int	result;
	int	i;

	i = 0;
	minus = 1;
	result = 0;
	while (ft_isspace(str[i]) == 1)
		i++;
	while (ft_isplmin(str[i]) != 0)
	{
		minus *= ft_isplmin(str[i]);
		i++;
	}
	while (ft_isnumber(str[i]) == 1)
	{
		result = result * 10 + (str[i] - 48);
		i++;
	}
	result *= minus;
	return (result);
}
