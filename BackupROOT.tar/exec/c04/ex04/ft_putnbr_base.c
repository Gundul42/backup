/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/24 08:27:19 by graja             #+#    #+#             */
/*   Updated: 2021/02/24 12:48:18 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putnbr(int nr, int base, char *str)
{
	char	c;

	if (nr < 0)
	{
		nr *= -1;
		write(1, "-", 1);
	}
	if (nr > base - 1)
	{
		ft_putnbr(nr / base, base, str);
	}
	c = str[nr % base];
	write(1, &c, 1);
}

int		ft_getmembers(char *ptr)
{
	int		i;
	int		j;
	int		k;

	i = 0;
	j = 0;
	while (ptr[i] != 0)
	{
		if ((ptr[i] == '-') || (ptr[i] == '+'))
			return (-1);
		i++;
	}
	while (j < i - 1)
	{
		k = j + 1;
		while (k < i)
		{
			if (ptr[j] == ptr[k])
				return (-1);
			k++;
		}
		j++;
	}
	return (i);
}

void	ft_putnbr_base(int nbr, char *base)
{
	int	basenr;

	basenr = ft_getmembers(base);
	if (basenr < 2)
		return ;
	ft_putnbr(nbr, basenr, base);
}
