/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/24 12:59:01 by graja             #+#    #+#             */
/*   Updated: 2021/02/24 14:47:14 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_isnumber(char c, char *pool)
{
	int	nbr;

	nbr = 0;
	while (pool[nbr] != 0)
	{
		if (c == pool[nbr])
			return (nbr);
		nbr++;
	}
	return (-1);
}

int	ft_isspace(char c)
{
	if ((c == 32) || ((c > 8) && (c < 14)))
		return (1);
	else
		return (0);
}

int	ft_getmembers(char *ptr)
{
	int		i;
	int		j;
	int		k;

	i = 0;
	j = 0;
	while (ptr[i] != 0)
	{
		if ((ptr[i] == '-') || (ptr[i] == '+'))
			return (-1);
		i++;
	}
	while (j < i - 1)
	{
		k = j + 1;
		while (k < i)
		{
			if (ptr[j] == ptr[k])
				return (-1);
			k++;
		}
		j++;
	}
	return (i);
}

int	ft_atoi(char *str, int basenr, char *pool)
{
	int	minus;
	int	result;
	int	i;

	i = 0;
	minus = 1;
	result = 0;
	while (ft_isspace(str[i]) == 1)
		i++;
	while ((str[i] == '-') || (str[i] == '+'))
	{
		if (str[i] == '-')
			minus *= -1;
		i++;
	}
	while (ft_isnumber(str[i], pool) >= 0)
	{
		result = result * basenr + ft_isnumber(str[i], pool);
		i++;
	}
	result *= minus;
	return (result);
}

int	ft_atoi_base(char *str, char *base)
{
	int	result;

	result = ft_getmembers(base);
	if (result < 2)
		return (0);
	result = ft_atoi(str, result, base);
	return (result);
}
