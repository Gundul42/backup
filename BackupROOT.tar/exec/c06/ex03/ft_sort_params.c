/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/24 18:53:13 by graja             #+#    #+#             */
/*   Updated: 2021/02/25 09:39:30 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print(char *ptr)
{
	while (*ptr > 0)
	{
		write(1, ptr, 1);
		ptr++;
	}
	write(1, "\n", 1);
}

int		ft_changeornot(char *ptr1, char *ptr2)
{
	while (*ptr1 > 0)
	{
		if (*ptr1 > *ptr2)
			return (1);
		if (*ptr1 < *ptr2)
			return (0);
		ptr1++;
		ptr2++;
	}
	return (0);
}

char	**ft_sort_params(int n, char **pool)
{
	int		i;
	int		exit;
	char	*ptr;

	exit = 1;
	while (exit != 0)
	{
		i = 1;
		exit = 0;
		while (i <= (n - 2))
		{
			if (*pool[i] >= *pool[i + 1])
			{
				if (ft_changeornot(pool[i], pool[i + 1]) != 0)
				{
					exit = 1;
					ptr = pool[i];
					pool[i] = pool[i + 1];
					pool[i + 1] = ptr;
				}
			}
			i++;
		}
	}
	return (pool);
}

int		main(int n, char **arg)
{
	int	i;

	i = 2;
	if (n > 2)
		arg = ft_sort_params(n, arg);
	if (n > 1)
	{
		while (i <= n)
		{
			ft_print(arg[i - 1]);
			i++;
		}
	}
	return (0);
}
