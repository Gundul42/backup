/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/21 12:26:08 by graja             #+#    #+#             */
/*   Updated: 2021/02/22 08:33:08 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s, char *src)
{
	char	*chk;
	char	*bkp;

	chk = s;
	bkp = src;
	while (*bkp != '\0')
	{
		if (*bkp > *chk)
			return (-1);
		if (*bkp < *chk)
			return (1);
		bkp++;
		chk++;
	}
	if (*bkp > *chk)
		return (-1);
	if (*bkp < *chk)
		return (1);
	return (0);
}
