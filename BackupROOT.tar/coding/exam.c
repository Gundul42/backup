#include <unistd.h>

void ft_print(char p)
{
        write(1, &p, 1);
}

void rotone_main(int argc, char **argv)
{
        char    *ptr;
        int             i;
        char    c;

        i = 0;
        ptr = *argv;
        while (i < argc)
        {
                c = *ptr;
                while (c != '\0')
                {
                        c = *ptr;
                        if (((c <= 'Z') && (c >= 'A'))  || ((c <= 'z') && (c >= 'a')))
                                ft_print(c);
                        ptr++;
                }
                i++;
                ft_print('\n');
        }
}

int    main(void)
{
	/*
  char *arg0 = {"abc"};
  char *arg1 = {"Les stagiaires du staff ne sentent pas toujours tres bon."};
  char *arg2 = {"AkjhZ zLKIJz , 23y "};
  char *arg3 = {"a", "b"};

  rotone_main(1, arg0);
  rotone_main(1, arg1);
  rotone_main(1, arg2);
  rotone_main(2, arg3);*/
	char *test = {"djdjdjdjdj"};
	rotone_main(1, test);
  return (0);
}
~                                                            
