#include <stdio.h>
int	ft_fibonacci(int test);

int     main(void)
{
        int     result;
        int     test;

        result = 0;
        test = -1;
	while (test < 32)
	{
                result = ft_fibonacci(test);
                printf("Fibonacci %d = %d\n", test, result);
		test++;
	}
        return (0);
}
