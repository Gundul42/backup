#include <stdio.h>
int	ft_find_next_prime(int nb);

int     main(void)
{
        int     result;
        int     test;

        result = 0;
        test = -5;
	while (test < 100)
	{
		result = ft_find_next_prime(test);
	                printf("Die nächste Primzahl >= %d ist %d# \n", test, result);
		test++;
	}
        return (0);
}
