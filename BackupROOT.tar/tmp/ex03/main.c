#include <stdio.h>

int     ft_recursive_power(int nb, int power);

int     main(void)
{
        int     result;
        int     test;
	int	power;

	power = -1;
        result = 0;
        test = 2;
	while (power < 32)
	{
                result = ft_recursive_power(test, power);
                printf("%d hoch %d = %d.\n", test, power, result);
		power++;
	}
        return (0);
}
