#include <stdio.h>
int	ft_is_prime(int nb);

int     main(void)
{
        int     result;
        int     test;

        result = 0;
        test = -5;
	while (test < 100)
	{
		if (ft_is_prime(test) == 1)
	                printf("%d ist eine Primzahl\n", test);
		test++;
	}
        return (0);
}
