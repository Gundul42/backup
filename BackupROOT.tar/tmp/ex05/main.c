#include <stdio.h>
int	ft_sqrt(int test);

int     main(void)
{
        int     result;
        int     test;

        result = 0;
        test = -10;
	while (test < 1032)
	{
                result = ft_sqrt(test);
                printf("Wurzel von %d = %d\n", test, result);
		test++;
	}
        return (0);
}
