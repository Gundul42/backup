#include <stdio.h>

int     ft_recursive_factorial(int nb);

int     main(void)
{
        int     result;
        int     test;

        result = 0;
        test = -5;
        while (test < 13)
        {
                result = ft_recursive_factorial(test);
                printf("%d Fakultaet = %d.\n", test, result);
                test++;
        }
        return (0);
}
