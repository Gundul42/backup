/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/17 15:00:41 by graja             #+#    #+#             */
/*   Updated: 2021/02/20 14:29:22 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_char_is_alpha(char c)
{
	if (((c >= 97) && (c <= 122)) || ((c >= 65) && (c <= 90)))
		return (1);
	else
		return (0);
}

int		ft_char_is_numeric(char c)
{
	if (((c >= 48) && (c <= 57)))
		return (1);
	else
		return (0);
}

int		ft_char_is_printable(char c)
{
	if (((c > 31) && (c < 127)))
		return (1);
	else
		return (0);
}

char	*ft_strcapitalize(char *str)
{
	char	*bkp;
	int		head;

	head = 1;
	bkp = str;
	while (*bkp != '\0')
	{
		if ((head == 1) && (*bkp >= 97) && (*bkp <= 122))
			*bkp = *bkp - 32;
		else if ((head == 0) && (*bkp >= 65) && (*bkp <= 90))
			*bkp = *bkp + 32;
		if (((ft_char_is_numeric(*bkp) == 0) &&
		(ft_char_is_alpha(*bkp) == 0)) || (ft_char_is_printable(*bkp == 0)))
			head = 1;
		else
			head = 0;
		bkp++;
	}
	return (str);
}
