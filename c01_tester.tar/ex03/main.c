/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/14 16:10:00 by graja             #+#    #+#             */
/*   Updated: 2021/02/16 09:17:46 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		ft_putchar('-');
		nb = -nb;
	}
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
		ft_putnbr(nb % 10);
	}
	else
	{
		ft_putchar(nb + 48);
	}
}

void	ft_div_mod(int a, int b, int *div, int *mod);

int		main(void)
{
	int	x;
	int	y;
	int	result;
	int	remain;	
	
	x = 80;
	y = 0;
	ft_div_mod(x, y, &result, &remain);
	ft_putnbr(result);
	ft_putchar('\n');
	ft_putnbr(remain);
	ft_putchar('\n');
	x = 0;
	y = 9;
	ft_div_mod(x, y, &result, &remain);
	ft_putnbr(result);
	ft_putchar('\n');
	ft_putnbr(remain);
	ft_putchar('\n');
	x = 80;
	y = 9;
	ft_div_mod(x, y, &result, &remain);
	ft_putnbr(result);
	ft_putchar('\n');
	ft_putnbr(remain);
	ft_putchar('\n');
	x = -80;
	y = 9;
	ft_div_mod(x, y, &result, &remain);
	ft_putnbr(result);
	ft_putchar('\n');
	ft_putnbr(remain);
	ft_putchar('\n');
	return (0);
}
