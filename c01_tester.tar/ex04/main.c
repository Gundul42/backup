/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/14 16:10:00 by graja             #+#    #+#             */
/*   Updated: 2021/02/16 08:11:02 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		ft_putchar('-');
		nb = -nb;
	}
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
		ft_putnbr(nb % 10);
	}
	else
	{
		ft_putchar(nb + 48);
	}
}

void	ft_ultimate_div_mod(int *a, int *b);

int		main(void)
{
	int	x;
	int	y;
	
	x = 0;
	y = 70;
	ft_ultimate_div_mod(&x, &y);
	ft_putnbr(x);
	ft_putchar('\n');
	ft_putnbr(y);
	ft_putchar('\n');
	ft_putchar('\n');
	x = 70;
	y = 0;
	ft_ultimate_div_mod(&x, &y);
	ft_putnbr(x);
	ft_putchar('\n');
	ft_putnbr(y);
	ft_putchar('\n');
	ft_putchar('\n');
	x = -90;
	y = 8;
	ft_ultimate_div_mod(&x, &y);
	ft_putnbr(x);
	ft_putchar('\n');
	ft_putnbr(y);
	ft_putchar('\n');
	ft_putchar('\n');
	x = 90;
	y = 7;
	ft_ultimate_div_mod(&x, &y);
	ft_putnbr(x);
	ft_putchar('\n');
	ft_putnbr(y);
	ft_putchar('\n');
	ft_putchar('\n');
	return (0);
}
