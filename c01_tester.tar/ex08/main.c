/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/14 16:10:00 by graja             #+#    #+#             */
/*   Updated: 2021/02/16 09:25:48 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		ft_putchar('-');
		nb = -nb;
	}
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
		ft_putnbr(nb % 10);
	}
	else
		ft_putchar(nb + 48);
}

void	ft_sort_int_tab(int *tab, int size);

int		main(void)
{
	int	revme[] = {1, -342, 433, -774, 5, -86, 7, -928, -232329, 2222222};
	int	i;

	i = 0;
	while (i < 10)
	{
		ft_putnbr(revme[i]);
		ft_putchar(',');
		ft_putchar(' ');
		i++;
	}
	ft_putchar('\n');
	i = 0;
	ft_sort_int_tab(&revme[0], 10);
	while (i < 10)
	{
		ft_putnbr(revme[i]);
		ft_putchar(',');
		ft_putchar(' ');
		i++;
	}
	ft_putchar('\n');
}
