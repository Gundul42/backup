/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/24 17:15:53 by graja             #+#    #+#             */
/*   Updated: 2021/02/25 09:08:41 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_params(char *args)
{
	while (*args > 0)
	{
		write(1, args, 1);
		args++;
	}
	write(1, "\n", 1);
}

int		main(int argc, char **argv)
{
	while (argc >= 2)
	{
		ft_print_params(argv[argc - 1]);
		argc--;
	}
	return (0);
}
