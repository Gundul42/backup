/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/24 17:03:11 by graja             #+#    #+#             */
/*   Updated: 2021/02/24 17:11:42 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_program_name(char *name)
{
	while (*name > 0)
	{
		write(1, name, 1);
		name++;
	}
	write(1, "\n", 1);
}

int		main(int argc, char **argv)
{
	ft_print_program_name(argv[argc - 1]);
	return (0);
}
