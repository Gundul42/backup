#include <string.h>
#include <unistd.h>

unsigned int	ft_strlen(char *ptr);

int				ft_strncmp(char *s1, char *s2, unsigned int n);

char	*ft_strstr(char *dst, char *src);

int		main(void)
{
	char	look[45] = "Bilang dulu, siapa namamu. Jangan malu2.";
	char	src[] = "siapa ";
	char	look1[45] = "Bilang dulu, siapa namamu. Jangan malu2.";
	char	src1[] = "siapa ";
	write(1, "\n", 1);
	write(1, &look, 40);
	write(1, "\n", 1);
	write(1, &src, 40);
	write(1, "\n", 1);
	write(1, strstr(&look[0], &src[0]), 45);
	write(1, "\n", 1);
	/*write(1, "Baru: \n", 7);*/
	write(1, ft_strstr(&look1[0], &src1[0]), 45);
	write(1, "\n", 1);
	return (0);
}

