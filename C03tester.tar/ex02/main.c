#include <string.h>
#include <unistd.h>

char	*ft_strcat(char *dst, char *src);

int		main(void)
{
	char	look[40] = "Bilang dulu,";
	char	src[] = " siapa namamu ?";
	char	look1[40] = "Bilang dulu,";
	char	src1[] = " siapa namamu ?";
	write(1, "\n", 1);
	write(1, &look, 40);
	write(1, "\n", 1);
	write(1, &src, 40);
	write(1, "\n", 1);
	write(1, strcat(&look[0], &src[0]), 40);
	write(1, "\n", 1);
	/*write(1, "Baru: \n", 7);*/
	write(1, ft_strcat(&look1[0], &src1[0]), 40);
	write(1, "\n", 1);
	return (0);
}

