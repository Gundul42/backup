#include <unistd.h>
#include <stdio.h>

unsigned int	ft_strlcat(char *dst, char *src, unsigned int n);

int				main(void)
{
	char	look1[21] = "Bilang dulu,";
	char	src1[] = " siapa namamu ?";

	printf("StrLen = %d\n",ft_strlcat(&look1[0], &src1[0], 21));
	write(1, &look1, 40);
	write(1, "\n", 1);
	return (0);
}

