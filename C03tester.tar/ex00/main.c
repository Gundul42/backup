#include <string.h>
#include <unistd.h>

int	ft_strcmp(char *a, char *b);

int	main(void)
{
	char	look[] = "suchmich ";
	char	src[] = "suchmich";
	int		back;

	back = strcmp(&look[0], &src[0]);
	if (back < 0)
		write(1, "kleiner\n", 8);
	else if (back == 0)
		write(1, "NULL\n", 5);
	else
		write(1, "groesser\n", 9);
	write(1, "Baru: \n", 7);
	back = ft_strcmp(&look[0], &src[0]);
	if (back < 0)
		write(1, "kleiner\n", 8);
	else if (back == 0)
		write(1, "NULL\n", 5);
	else
		write(1, "groesser\n", 9);
	return (0);
	write(1, "\n\n", 2);
	return (0);
}

