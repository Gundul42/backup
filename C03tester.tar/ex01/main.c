#include <string.h>
#include <unistd.h>

int	ft_strncmp(char *a, char *b, unsigned int n);

int	printnr(int back)
{
	if (back < 0)
		write(1, "kleiner\n", 8);
	else if (back == 0)
		write(1, "NULL\n", 5);
	else
		write(1, "groesser\n", 9);
	return (back);
}

int	main(void)
{
	char	look[] = "suchm";
	char	src[] = "suchmich";

	write(1, "\n", 1);
	printnr(strncmp(&look[0], &src[0], 9));
	write(1, "Baru: \n", 7);
	printnr( ft_strncmp(&look[0], &src[0], 9));
	write(1, "\n", 1);
	return (0);
}

