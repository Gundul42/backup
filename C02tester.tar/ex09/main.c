/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/17 15:00:41 by graja             #+#    #+#             */
/*   Updated: 2021/02/19 17:16:44 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

char	*ft_strcapitalize(char *str);

int		main(void)
{
	char	chk1[] = "please say it+agai9s";
	char	chk2[] = "900m and tom+lisa sa";
	char    chk3[] = "mamMa said:leave_it_";
	char	chk4[] = "no_WORD_hat\x03to writ";
	char	chk5[] = "";

	write(1, &chk1[0], 20);
	ft_putchar('\n');
	write(1, ft_strcapitalize(&chk1[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk2[0], 20);
	ft_putchar('\n');
	write(1, ft_strcapitalize(&chk2[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk3[0], 20);
	ft_putchar('\n');
	write(1, ft_strcapitalize(&chk3[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk4[0], 20);
	ft_putchar('\n');
	write(1, ft_strcapitalize(&chk4[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, "EmptyString", 11);
	ft_putchar('\n');
	write(1, ft_strcapitalize(&chk5[0]), 1);
	ft_putchar('\n');
	ft_putchar('\n');
	return (0);
}

