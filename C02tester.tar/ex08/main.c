/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/20 10:35:42 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

char	*ft_strlowcase(char *str);

int		main(void)
{
	char	chk1[] = "HEREISHatiwanttocopy";
	char	chk2[] = "hereishatiWANTtocopy";
	char    chk3[] = "her@ISHAtw123450copy";
	char	chk4[] = "hereisHATIWANttocop]";
	char	chk5[] = "";

	write(1, &chk1[0], 20);
	ft_putchar('\n');
	write(1, ft_strlowcase(&chk1[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk2[0], 20);
	ft_putchar('\n');
	write(1, ft_strlowcase(&chk2[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk3[0], 20);
	ft_putchar('\n');
	write(1, ft_strlowcase(&chk3[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk4[0], 20);
	ft_putchar('\n');
	write(1, ft_strlowcase(&chk4[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, "EmptyString", 11);
	ft_putchar('\n');
	write(1, ft_strlowcase(&chk5[0]), 1);
	ft_putchar('\n');
	ft_putchar('\n');
	return (0);
}
