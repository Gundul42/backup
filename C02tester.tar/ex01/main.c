/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/20 09:35:18 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <string.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

char	*ft_strncpy(char *dest, char *src, unsigned int n);

int		main(void)
{
	char	mytab[] = "here is what I want to copy";
	char	cptab[17];

	write(1, ft_strncpy(&cptab[0], &mytab[0], 17), 37);
	ft_putchar('\n');
	write(1, strncpy(&cptab[0], &mytab[0], 17), 37);
	ft_putchar('\n');
}
