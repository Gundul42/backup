/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/18 07:52:22 by graja             #+#    #+#             */
/*   Updated: 2021/02/19 08:55:00 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_putstr_non_printable(char *str);

int		main(void)
{
	char test[] = "Dies ist mal ein\n super test";
	char test1[] = "Dies ist ~al ein\n su\x0c er test";
	char test2[] = "Dies \x7fmal ein\n super test";
	ft_putstr_non_printable(&test[0]);
	ft_putchar('\n');
	ft_putstr_non_printable(&test1[0]);
	ft_putchar('\n');
	ft_putstr_non_printable(&test2[0]);
	ft_putchar('\n');
}


