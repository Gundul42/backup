/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/18 18:04:28 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int		ft_str_is_lowercase(char *str);

int		main(void)
{
	char	chk1[] = "hereishatiwanttocopy";
	char	chk2[] = "hereishatiWANTtocopy";
	char    chk3[] = "her@ishatwwanttocopy";
	char	chk4[] = "hereishatiwanttocop]";
	char	chk5[] = "";
	int		back;

	write(1, &chk1[0], 20);
	ft_putchar('\n');
	back = ft_str_is_lowercase(&chk1[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk2[0], 20);
	ft_putchar('\n');
	back = ft_str_is_lowercase(&chk2[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk3[0], 20);
	ft_putchar('\n');
	back = ft_str_is_lowercase(&chk3[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk4[0], 20);
	ft_putchar('\n');
	back = ft_str_is_lowercase(&chk4[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, "EmptyString", 12);
	ft_putchar('\n');
	back = ft_str_is_lowercase(&chk5[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	return (0);
}
