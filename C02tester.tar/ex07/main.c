/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/20 10:26:39 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

char	*ft_strupcase(char *str);

int		main(void)
{
	char	chk1[] = "hereishatiwanttocopy";
	char	chk2[] = "hereishatiWANTtocopy";
	char    chk3[] = "her@ishatwwanttocopy";
	char	chk4[] = "hereishatiwanttocop]";
	char	chk5[] = "";

	write(1, &chk1[0], 20);
	ft_putchar('\n');
	write(1, ft_strupcase(&chk1[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk2[0], 20);
	ft_putchar('\n');
	write(1, ft_strupcase(&chk2[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk3[0], 20);
	ft_putchar('\n');
	write(1, ft_strupcase(&chk3[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk4[0], 20);
	ft_putchar('\n');
	write(1, ft_strupcase(&chk4[0]), 20);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, "EmptyString", 11);
	ft_putchar('\n');
	write(1, ft_strupcase(&chk5[0]), 1);
	ft_putchar('\n');
	ft_putchar('\n');
	return (0);
}
