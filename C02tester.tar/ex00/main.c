/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/18 17:59:52 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

char	*ft_strcpy(char *dest, char *src);

int		main(void)
{
	char	mytab[] = "here is what I want to copy";
	char	cptab[27];
	char	*dest;

	dest = ft_strcpy(&cptab[0], &mytab[0]);
	write(1, dest, 27);
	ft_putchar('\n');
}
