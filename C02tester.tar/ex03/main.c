/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/16 11:05:55 by graja             #+#    #+#             */
/*   Updated: 2021/02/18 18:03:31 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

int		ft_str_is_numeric(char *str);

int		main(void)
{
	char	chk1[] = "12345678901234567890";
	char	chk2[] = "1234567890123456789:";
	char    chk3[] = "1234567890/234567890";
	char	chk4[] = "123456789012345A7890";
	char	chk5[] = "";
	int		back;

	write(1, &chk1[0], 20);
	ft_putchar('\n');
	back = ft_str_is_numeric(&chk1[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk2[0], 20);
	ft_putchar('\n');
	back = ft_str_is_numeric(&chk2[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk3[0], 20);
	ft_putchar('\n');
	back = ft_str_is_numeric(&chk3[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, &chk4[0], 20);
	ft_putchar('\n');
	back = ft_str_is_numeric(&chk4[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	write(1, "EmptyString", 12);
	ft_putchar('\n');
	back = ft_str_is_numeric(&chk5[0]);
	if (back == 0)
	write(1, "NO\n", 3);
	else
	write(1, "YES\n", 4);
	ft_putchar('\n');
	ft_putchar('\n');
	return (0);
}
