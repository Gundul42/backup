/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: graja <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/02/18 10:32:02 by graja             #+#    #+#             */
/*   Updated: 2021/02/20 14:21:25 by graja            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


void	*ft_print_memory(void *addr, unsigned int size);

int		main(void)
{
	char	c[] = "Ich habe keine Ahnung und wer";
	char	p[][23] = {"Diest ist mal ein test", "und Hier noch einer"};
       
	ft_print_memory(&c[0], 100);
	ft_print_memory(&p[0], 100);
	return (0);
}
