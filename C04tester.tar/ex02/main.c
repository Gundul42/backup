void	ft_putnbr(int nb);

int	main(void)
{
	int	test = -2147483647;

	ft_putnbr(test);
	return (0);
}
