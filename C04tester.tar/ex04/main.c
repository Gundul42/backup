void	ft_putnbr_base(int nbr, char *base);

int		main(void)
{
	char test[] = "";

	ft_putnbr_base(-82179177, &test[0]);
	return (0);
}
