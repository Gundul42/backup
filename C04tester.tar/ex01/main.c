void	ft_putstr(char *str);

int		main(void)
{
	char	test[]="Schreib mal wieder !";

	ft_putstr(&test[0]);
	return (0);
}
