#include <stdio.h>

int	ft_atoi_base(char *str,char *base);

int	main(void)
{
	int result;
	char	nbr[] = "   \n \f  +++--+-8ff6a1";
	char	base[] = "0123456789abcdef";

	result = ft_atoi_base(&nbr[0], &base[0]);
	printf("Result: %d\n", result);
	return (0);
}
