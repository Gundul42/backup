#include <stdio.h>

int	ft_atoi(char *str);

int	main(void)
{
	int	test;
	char	tonbr[] = "\n\t	 \r \f \x0d  --++-+-+120456084";

	test = ft_atoi(&tonbr[0]);
	printf("ToNumber %d \n", test);
	return (0);
}
