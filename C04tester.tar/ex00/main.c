#include <unistd.h>
#include <string.h>
#include <stdio.h>

int	ft_strlen(char *dst);

int				main(void)
{
	char	look1[21] = "Bilang dulu,";

	printf("StrLen = %d\n",ft_strlen(&look1[0]));
	printf("StrLen = %lu\n",strlen(&look1[0]));
	return (0);
}

